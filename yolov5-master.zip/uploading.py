import ftplib
def uploading():
    session = ftplib.FTP()
    session.connect('호스트명',포트번호) # 두 번째 인자는 port number
    session.login("아이디", "패스워드")    # FTP 서버에 접속
    
    uploadfile = open('C:/yolov5-master/runs/detect/exp/labels/logs.txt' ,mode='rb') #업로드할 파일 open
 
    session.encoding='utf-8'
    session.storbinary('STOR ' + '저장할 위치의 경로/logs.txt', uploadfile) #파일 업로드
 
    uploadfile.close() # 파일 닫기
 
    session.quit() # 서버 나가기
